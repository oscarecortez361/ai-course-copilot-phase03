import os, yaml, numpy as np, pandas as pd
from sentence_transformers import SentenceTransformer
import faiss

CFG = yaml.safe_load(open("config.yaml"))
PROC_DIR = CFG["data"]["processed"]
EMB_DIR = CFG["embeddings"]["dir"]
FAISS_DIR = CFG["indexes"]["faiss_dir"]
MODEL_NAME = CFG["embed_model"]

os.makedirs(EMB_DIR, exist_ok=True)
os.makedirs(FAISS_DIR, exist_ok=True)

chunks_path = os.path.join(PROC_DIR, "chunks.parquet")
df = pd.read_parquet(chunks_path)
texts = df["text"].tolist()

print(f"Embedding {len(texts)} chunks with {MODEL_NAME} …")
model = SentenceTransformer(MODEL_NAME)
emb = model.encode(texts, batch_size=64, convert_to_numpy=True, show_progress_bar=True)
np.save(os.path.join(EMB_DIR, "chunks.npy"), emb)

# build cosine index
faiss.normalize_L2(emb)
index = faiss.IndexFlatIP(emb.shape[1])
index.add(emb)
faiss.write_index(index, os.path.join(FAISS_DIR, "flat_cosine.index"))

# Save ids map
df[\"chunk_id\"].to_csv(os.path.join(FAISS_DIR, \"ids.csv\"), index=False)
print(\"Saved FAISS index and embeddings.\")
