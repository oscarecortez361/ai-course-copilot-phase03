import os, time, json, yaml, numpy as np, pandas as pd
import faiss

CFG = yaml.safe_load(open("config.yaml"))
PROC_DIR = CFG["data"]["processed"]
FAISS_DIR = CFG["indexes"]["faiss_dir"]

def load_index():
    index = faiss.read_index(os.path.join(FAISS_DIR, "flat_cosine.index"))
    ids = pd.read_csv(os.path.join(FAISS_DIR, "ids.csv"))["chunk_id"].tolist()
    return index, ids

def embed_queries(qs, model_name):
    from sentence_transformers import SentenceTransformer
    import faiss, numpy as np
    model = SentenceTransformer(model_name)
    vecs = model.encode(qs, batch_size=32, convert_to_numpy=True, show_progress_bar=False)
    faiss.normalize_L2(vecs)
    return vecs

def compute_metrics(preds, golds, ks=(5,10)):
    out = {}
    for k in ks:
        rec = []
        mrr = []
        for p, g in zip(preds, golds):
            topk = p[:k]
            rec.append(1.0 if any(x in g for x in topk) else 0.0)
            rr = 0.0
            for rank, cid in enumerate(topk, start=1):
                if cid in g:
                    rr = 1.0 / rank
                    break
            mrr.append(rr)
        out[f"R@{k}"] = float(np.mean(rec)) if rec else 0.0
        out[f"MRR@{k}"] = float(np.mean(mrr)) if mrr else 0.0
    return out

def main(out_path):
    df = pd.read_parquet(os.path.join(PROC_DIR, "chunks.parquet"))
    index, ids = load_index()
    # Load queries
    qfile = CFG["eval"]["queries"]
    lines = [json.loads(x) for x in open(qfile, "r", encoding="utf-8") if x.strip()]
    queries = [x["q"] for x in lines]
    gold = [set(x.get("rel_chunk_ids", [])) for x in lines]

    qvecs = embed_queries(queries, CFG["embed_model"])
    import time
    t0 = time.time()
    D, I = index.search(qvecs, 10)
    avg_latency = (time.time() - t0) / max(1, len(queries))
    preds = [[ids[i] for i in row] for row in I]

    m = compute_metrics(preds, gold, ks=(5,10))
    out = {
        "n_queries": len(queries),
        "R@5": m["R@5"],
        "R@10": m["R@10"],
        "MRR@5": m["MRR@5"],
        "MRR@10": m["MRR@10"],
        "avg_latency_sec": avg_latency
    }
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print("Metrics →", out_path, out)

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="eval/results/metrics.json")
    args = ap.parse_args()
    main(args.out)
