import os, re, yaml, pandas as pd
CFG = yaml.safe_load(open("config.yaml"))
REG = "data/registry.csv"
PROC_DIR = CFG["data"]["processed"]
CHUNK_SIZE = int(CFG["chunk_size"])
OVERLAP = int(CFG["chunk_overlap"])

os.makedirs(PROC_DIR, exist_ok=True)

def load_text(path):
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        return f.read()

def normalize(txt):
    txt = txt.replace("\xa0"," ").replace("\r"," ")
    txt = re.sub(r"[ \t]+"," ", txt)
    txt = re.sub(r"\n{3,}","\n\n", txt)
    return txt.strip()

def chunk_words(txt, size=220, overlap=40):
    words = txt.split()
    chunks = []
    start = 0
    cid = 0
    while start < len(words):
        end = min(start + size, len(words))
        chunk = " ".join(words[start:end]).strip()
        if chunk:
            chunks.append((cid, chunk))
            cid += 1
        if end == len(words): break
        start = max(0, end - overlap)
    return chunks

def main():
    if not os.path.exists(REG):
        raise SystemExit("Run scripts/01_ingest.py first.")
    df = pd.read_csv(REG)
    rows = []
    for _, r in df.iterrows():
        text = normalize(load_text(r["source_path"]))
        for cid, chunk in chunk_words(text, CHUNK_SIZE, OVERLAP):
            rows.append({
                "chunk_id": f"{r['doc_id']}_{cid:04d}",
                "doc_id": r["doc_id"],
                "doc_title": r["title"],
                "doc_type": r["type"],
                "course": r.get("course",""),
                "week": r.get("week",""),
                "section_heading": "",
                "text": chunk,
                "tokens": len(chunk.split())
            })
    out = os.path.join(PROC_DIR, "chunks.parquet")
    pd.DataFrame(rows).to_parquet(out, index=False)
    print(f"Wrote {len(rows)} chunks → {out}")

if __name__ == "__main__":
    main()
