print('No supervised training for retrieval in this baseline. Skipping…')
