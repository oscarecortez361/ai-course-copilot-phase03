import os, csv, glob, yaml
CFG = yaml.safe_load(open("config.yaml"))
RAW = CFG["data"]["raw"]
os.makedirs(RAW, exist_ok=True)

def list_docs():
    exts = (".txt", ".md")
    for path in glob.glob(os.path.join(RAW, "**", "*"), recursive=True):
        if os.path.isfile(path) and path.lower().endswith(exts):
            yield path

def main():
    rows = []
    for i, path in enumerate(sorted(list_docs()), start=1):
        doc_id = f"D{i:03d}"
        title = os.path.basename(path)
        rows.append({
            "doc_id": doc_id, "title": title, "type": "course_doc",
            "course": "", "week": "", "pages": "",
            "source_path": path.replace("\\", "/"),
            "license": "instructor-approved / OER", "notes": ""
        })
    out = "data/registry.csv"
    os.makedirs("data", exist_ok=True)
    import csv
    with open(out, "w", newline="", encoding="utf-8") as f:
        fieldnames = ["doc_id","title","type","course","week","pages","source_path","license","notes"]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for r in rows:
            writer.writerow(r)
    print(f"Wrote {len(rows)} entries to {out}. Put .txt or .md in {RAW}.")

if __name__ == "__main__":
    main()
